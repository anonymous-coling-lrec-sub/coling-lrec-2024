﻿import inspect
import transformers.data.metrics.squad_metrics as squad_metrics
from lm_eval.base import Task, rf, mean
from itertools import zip_longest


class DART(Task):
    VERSION = 0
    DATASET_PATH = "dart"
    DATASET_NAME = None
    
    def has_training_docs(self):
        return True

    def has_validation_docs(self):
        return True

    def has_test_docs(self):
        return True

    def training_docs(self):
        if self._training_docs is None:
            self._training_docs = list(self.dataset["train"])
        
        return self._training_docs

    def validation_docs(self):
        if self.has_validation_docs():
            return self.dataset["validation"]
    
    def test_docs(self):
        if self.has_test_docs():
            return self.dataset["test"]

    def doc_to_text(self, doc):
            return "{}\nQuestion: {} True, False or Neither?\nAnswer:".format(
                doc["premise"],
                doc["hypothesis"].strip()
                + ("" if doc["hypothesis"].strip().endswith(".") else "."),
            )

    def doc_to_target(self, doc):
        # True = entailment
        # False = contradiction
        # Neither = neutral
        return " {}".format({0: "True", 1: "Neither", 2: "False"}[doc["label"]])

    def to_text(self,doc):
        return doc["premise"] + ' ' + doc["hypothesis"].strip()

    def construct_requests(self, doc, ctx):
        ll_true, _ = rf.loglikelihood(ctx, " True")
        ll_neither, _ = rf.loglikelihood(ctx, " Neither")
        ll_false, _ = rf.loglikelihood(ctx, " False")
        return ll_true, ll_neither, ll_false

    def construct_robust_requests(self, doc, ctx):
        ll_true, _ = rf.loglikelihood(ctx, f" {doc['possible_labels'][0]}")
        ll_neither, _ = rf.loglikelihood(ctx, f" {doc['possible_labels'][1]}")
        ll_false, _ = rf.loglikelihood(ctx, f" {doc['possible_labels'][2]}")
        return ll_true, ll_neither, ll_false

    def process_results(self, doc, results):
        gold = doc["label"]
        pred = np.argmax(results)
        return {"acc": pred == gold}

    def higher_is_better(self):
        return {"acc": True}

    def aggregation(self):
        return {"acc": mean}
    

def camel_case_split(identifier):
    matches = re.finditer('.+?(?:(?<=[a-z])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])|$)', identifier)
    d = [m.group(0) for m in matches]
    new_d = []
    for token in d:
        token = token.replace('(', '')
        token_split = token.split('_')
        for t in token_split:
            #new_d.append(t.lower())
            new_d.append(t)
    return new_d
