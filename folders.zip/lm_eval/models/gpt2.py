import transformers
import torch
import torch.nn as nn
from lm_eval.base import BaseLM
from lm_eval.modeling._gpt2 import GPT2LMHeadModel, GPT2ForSequenceClassification

class HFLM(BaseLM):
    def __init__(
        self,
        device="cuda",
        pretrained="gpt2",
        revision="main",
        subfolder=None,
        tokenizer=None,
        batch_size=1,
        **kwargs,
    ):
        super().__init__()

        assert isinstance(device, str)
        assert isinstance(pretrained, str)
        assert isinstance(batch_size, int)

        if device:
            if device not in ["cuda", "cpu"]:
                device = int(device)
            self._device = torch.device(device)
            print(f"Using device '{device}'")
        else:
            print("Device not specified")
            print(f"Cuda Available? {torch.cuda.is_available()}")
            self._device = (
                torch.device("cuda")
                if torch.cuda.is_available()
                else torch.device("cpu")
            )
        
        self.dev_num = None
        self.tok_pos = None
        # TODO: update this to be less of a hack once subfolder is fixed in HF
        revision = revision + ("/" + subfolder if subfolder is not None else "")
        self.config = config = transformers.AutoConfig.from_pretrained(pretrained)
        
        self.gpt2 = GPT2LMHeadModel.from_pretrained(
            pretrained,
            # problem_type="single_label_classification",
            revision=revision,
            # num_labels=kwargs['num_labels'],
            output_hidden_states=True).to(self.device)
        self.gpt2.eval()

        self.tokenizer = transformers.AutoTokenizer.from_pretrained(
            pretrained if tokenizer is None else tokenizer,
            add_prefix_space=True,
            revision=revision,
            add_special_tokens=False,
        )

        print('tokenizer',self.tokenizer)

        assert isinstance(
            self.tokenizer,
            (
                transformers.GPT2Tokenizer,
                transformers.GPT2TokenizerFast,
                transformers.T5Tokenizer,
                transformers.T5TokenizerFast,
            ),
        ), "this tokenizer has not been checked for compatibility yet!"

        self.vocab_size = self.tokenizer.vocab_size

        if isinstance(
            self.tokenizer, (transformers.GPT2Tokenizer, transformers.GPT2TokenizerFast)
        ):
            assert self.tokenizer.encode("hello\n\nhello") == [
                23748,
                198,
                198,
                31373,
            ], self.tokenizer.encode("hello\n\nhello")

        # multithreading and batching
        self.batch_size_per_gpu = batch_size  # todo: adaptive batch size
        
        #soft stuff augmentation
        self.soft_embedding_tokens = 20
        cloze_mask = torch.LongTensor([[1]*self.soft_embedding_tokens])#.to(device)
        cloze_mask = torch.LongTensor(cloze_mask).bool()#.to(device)
        self.soft_tokens = torch.LongTensor(list(range(len(cloze_mask[0]))))#.to(torch.bfloat16) 
        self.soft_embeding_before = nn.Embedding(len(cloze_mask[0]), config.hidden_size)
        self.soft_embeding_after = nn.Embedding(len(cloze_mask[0]), config.hidden_size)

        self.control_trans = nn.Sequential(
            nn.Linear(config.hidden_size, config.hidden_size//2),
            nn.Tanh(),
            nn.Linear(config.hidden_size//2, config.hidden_size//2),
            nn.Tanh(),
            nn.Linear(config.hidden_size//2, config.hidden_size)
            )
        

    @property
    def eot_token_id(self):
        # we use EOT because end of *text* is more accurate for what we're doing than end of *sentence*
        return self.tokenizer.eos_token_id

    @property
    def max_length(self):
        try:
            return self.gpt2.config.n_ctx
        except AttributeError:
            # gptneoconfig doesn't have n_ctx apparently
            return self.gpt2.config.max_position_embeddings

    @property
    def max_gen_toks(self):
        return 256

    @property
    def batch_size(self):
        # TODO: fix multi-gpu
        return self.batch_size_per_gpu  # * gpus

    @property
    def device(self):
        # TODO: fix multi-gpu
        return self._device
    
    @property
    def token_pos(self):
        return self.tok_pos

    def tok_encode(self, string: str):
        return self.tokenizer.encode(string, add_special_tokens=False)

    def tok_decode(self, tokens):
        return self.tokenizer.batch_decode(tokens)

    def _model_call(self, inps):
        """
        inps: a torch tensor of shape [batch, sequence]
        the size of sequence may vary from call to call

        returns: a torch tensor of shape [batch, sequence, vocab] with the
        logits returned from the model
        """
        yes = self.tok_pos not in ["none",None,"None"]
        
        label_shift_pos = self.soft_embedding_tokens
        self.gpt2.eval()
       
        with torch.no_grad():
            if yes:
                input_embeds = self.gpt2.get_input_embeddings()(inps).to(self.dev_num)
                emb_before = self.soft_embeding_before(self.soft_tokens).unsqueeze(0).to(self.dev_num)
                emb_after = self.soft_embeding_after(self.soft_tokens).unsqueeze(0).to(self.dev_num)
                emb_before = emb_before.repeat(inps.shape[0],1,1)
                emb_after = emb_after.repeat(inps.shape[0],1,1)
                if self.token_pos == "both":
                    emb_before = self.control_trans(emb_before).to(self.dev_num)
                    emb_after = self.control_trans(emb_after).to(self.dev_num)
                    temp_cat = torch.cat((emb_before,input_embeds),1)
                    all_cat = torch.cat((temp_cat,emb_after),1).to(torch.bfloat16)
                    
                    label_shift = [label_shift_pos,label_shift_pos]
                elif self.token_pos == "prefix":
                    emb_before = self.control_trans(emb_before).to(self.dev_num)
                    all_cat = torch.cat((emb_before,input_embeds),1).to(torch.bfloat16)
                    label_shift = [label_shift_pos,0]
                elif self.token_pos == "suffix":
                    emb_after = self.control_trans(emb_after).to(self.dev_num)
                    all_cat = torch.cat((input_embeds,emb_after),1).to(torch.bfloat16)
                    label_shift = [0,label_shift_pos]
                
                
                return self.gpt2(inputs_embeds=all_cat,)#[0][:, :, :self.config.vocab_size]
        # print('pure return')
            
            return self.gpt2(inps)[0][:, :, :self.config.vocab_size]

        with torch.no_grad():
            return self.gpt2(inps)[0][:, :, :50257]

    def _model_generate(self, context, max_length, eos_token_id):
        return self.gpt2.generate(
            context, max_length=max_length, eos_token_id=eos_token_id, do_sample=False
        )


# for backwards compatibility
GPT2LM = HFLM
