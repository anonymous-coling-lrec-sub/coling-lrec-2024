﻿import transformers
import torch
import torch.nn as nn
from lm_eval.base import BaseLM,Seq2Seq
from lm_eval.modeling._t5 import T5ForConditionalGeneration
from prompt_encoder import PrefixEncoder
from transformers import T5Tokenizer, PretrainedConfig

class T5N(Seq2Seq):
    def __init__(
        self,
        device="cuda",
        # pretrained="google/t5-v1_1-small",
        pretrained="t5-small",
        revision="main",
        subfolder=None,
        tokenizer=None,
        batch_size=1,
        **kwargs,
    ):
        super().__init__()

        assert isinstance(device, str)
        assert isinstance(pretrained, str)
        assert isinstance(batch_size, int)

        if device:
            if device not in ["cuda", "cpu"]:
                device = int(device)
            self._device = torch.device(device)
            print(f"Using device '{device}'")
        else:
            print("Device not specified")
            print(f"Cuda Available? {torch.cuda.is_available()}")
            self._device = (
                torch.device("cuda")
                if torch.cuda.is_available()
                else torch.device("cpu")
            )
        
        self.dev_num = None
        self.tok_pos = None
        # TODO: update this to be less of a hack once subfolder is fixed in HF
        revision = revision + ("/" + subfolder if subfolder is not None else "")
        self.config = config = transformers.AutoConfig.from_pretrained(pretrained)
        config.dropout_rate = 0
        self.t5 = T5ForConditionalGeneration.from_pretrained(
            pretrained,
            config=config,
            revision=revision,).to(self.device)
        self.t5.eval()

        self.tokenizer = T5Tokenizer.from_pretrained(
            pretrained if tokenizer is None else tokenizer,
            add_prefix_space=True,
            revision=revision,
            add_special_tokens=False,
        )

        assert isinstance(
            self.tokenizer,
            (
                transformers.T5Tokenizer,
                transformers.T5TokenizerFast,
            ),
        ), "this tokenizer has not been checked for compatibility yet!"

        self.vocab_size = self.tokenizer.vocab_size

        if isinstance(
            self.tokenizer, (transformers.T5Tokenizer, transformers.T5TokenizerFast)
        ):
            assert self.tokenizer.encode("hello\n\nhello") == [
                21820, 21820, 1
            ], self.tokenizer.encode("hello\n\nhello")

        # multithreading and batching
        self.batch_size_per_gpu = batch_size  # todo: adaptive batch size
        
        #soft stuff augmentation
        self.soft_embedding_tokens = 20
        prefix_config = {}
        prefix_config['pre_seq_len'] = self.soft_embedding_tokens
        prefix_config['tok_pos'] = self.tok_pos
        prefix_config['hidden_size'] = config.hidden_size
        prefix_config['num_hidden_layers'] = config.num_hidden_layers
        prefix_config = PretrainedConfig.from_dict(prefix_config)
        self.prompt_encoder = PrefixEncoder(prefix_config)
        

        self.soft_tokens = torch.arange(self.soft_embedding_tokens).long()
        

    @property
    def eot_token_id(self):
        # we use EOT because end of *text* is more accurate for what we're doing than end of *sentence*
        return self.tokenizer.eos_token_id

    @property
    def max_length(self):
        try:
            return self.t5.config.n_ctx
        except AttributeError:
            # gptneoconfig doesn't have n_ctx apparently
            # return self.t5.config.max_position_embeddings
            return 256

    @property
    def max_gen_toks(self):
        return 256

    @property
    def batch_size(self):
        # TODO: fix multi-gpu
        return self.batch_size_per_gpu  # * gpus

    @property
    def device(self):
        # TODO: fix multi-gpu
        return self._device
    
    @property
    def token_pos(self):
        return self.tok_pos

    def tok_encode(self, string: str):
        return self.tokenizer.encode(
                string)

    def tok_decode(self, tokens):
        return self.tokenizer.batch_decode(tokens,skip_special_tokens=True)

    def tok_encode_batch(self,tokens):
        return self.tokenizer(
                tokens,
                padding=True,
                return_tensors='pt')

    def _model_call(self, inputs,labels=None):
        """
        inps: a torch tensor of shape [batch, sequence]
        the size of sequence may vary from call to call

        returns: a torch tensor of shape [batch, sequence, vocab] with the
        logits returned from the model
        """
        yes = self.tok_pos not in ["none",None,"None"]
        
        label_shift_pos = self.soft_embedding_tokens
        self.t5.eval()
       
        with torch.no_grad():
            if yes:
                inps = inputs

                input_embeds = self.t5.get_input_embeddings()(inps['input_ids']).to(self.dev_num)
                attention_mask = inps['attention_mask']



                emb_before,emb_after = self.prompt_encoder(self.soft_tokens)

                emb_before = emb_before.unsqueeze(0).to(self.dev_num)
                emb_after = emb_after.unsqueeze(0).to(self.dev_num)
                emb_before = emb_before.repeat(inps['input_ids'].shape[0],1,1)
                emb_after = emb_after.repeat(inps['input_ids'].shape[0],1,1)
                asoft_mask = torch.tensor([1]*label_shift_pos).unsqueeze(0).to(self.dev_num)
                asoft_mask = asoft_mask.repeat(inps['input_ids'].shape[0],1)
                exit()
                if self.token_pos == "both":
                    temp_cat = torch.cat((emb_before,input_embeds),1)
                    all_cat = torch.cat((temp_cat,emb_after),1).to(torch.bfloat16)
                    attention_mask = torch.cat((asoft_mask,attention_mask,asoft_mask),-1)

                elif self.token_pos == "prefix":
                    all_cat = torch.cat((emb_before,input_embeds),1).to(torch.bfloat16)
                    attention_mask = torch.cat((asoft_mask,attention_mask),-1)

                elif self.token_pos == "suffix":
                    all_cat = torch.cat((input_embeds,emb_after),1).to(torch.bfloat16)
                    attention_mask = torch.cat((attention_mask,asoft_mask),-1)
                

                encoder_outputs = self.t5.encoder(
                                    inputs_embeds=all_cat,
                                    attention_mask=attention_mask,
                                    )



                return self.t5(
                        encoder_outputs = encoder_outputs, 
                        attention_mask=attention_mask,
                        labels=labels["input_ids"],
                    )
                
                # return self.t5.generate(
                #         input_ids = inps, 
                #         attention_mask=am,  
                #         max_length=10
                #     )
            # print(inputs.dtype,inputs.shape)
            # print(inputs.size())

            # print(inputs, labels["input_ids"])
            return self.t5(
            **inputs,
            labels=labels["input_ids"]
        )
        

    def _model_generate(self,context):#, max_length, eos_token_id):
        """
        return self.t5.generate(
            context, max_length=max_length, eos_token_id=eos_token_id, do_sample=False
        )
        """
        return self.t5.generate(
            **context
        )


# def weights_init(m):
#     classname = m.__class__.__name__
#     if classname.find('Linear') != -1:
#         torch.nn.init.normal_(m.weight)
   