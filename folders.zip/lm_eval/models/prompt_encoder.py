﻿import torch


class PrefixEncoder(torch.nn.Module):
    r'''
    The torch.nn model to encode the prefix
    Input shape: (batch-size, prefix-length)
    Output shape: (batch-size, prefix-length, 2*layers*hidden)
    '''
    def __init__(self, config):
        super().__init__()
        self.tok_pos = config.tok_pos
        # Use a two-layer MLP to encode the prefix
        config.pre_seq_len = 20
        self.soft_embeding_before = torch.nn.Embedding(config.pre_seq_len, config.hidden_size)
        self.soft_embeding_after = torch.nn.Embedding(config.pre_seq_len, config.hidden_size)
        torch.nn.init.xavier_uniform_(self.soft_embeding_before.weight)
        torch.nn.init.xavier_uniform_(self.soft_embeding_after.weight)
        
        self.trans = torch.nn.Sequential(
            torch.nn.Linear(config.hidden_size, config.prefix_hidden_size),
            torch.nn.Tanh(),
            torch.nn.Linear(config.prefix_hidden_size, config.num_hidden_layers * 2 * config.hidden_size)
        )
        

    def forward(self, prefix: torch.Tensor):
        
        prefix_tokens = self.soft_embeding_before(prefix)
        suffix_tokens = self.soft_embeding_after(suffix)

        
        prefix_pkv = self.trans(prefix_tokens)
        suffix_pkv = self.trans(suffix_tokens)

        return prefix_pkv,suffix_pkv